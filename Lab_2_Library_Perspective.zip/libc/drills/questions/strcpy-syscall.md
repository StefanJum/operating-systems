# strcpy() System Call

## Question Text

What system call does the `strcpy()` function invoke?

## Question Answers

- `cpy`

- `touch`

- `memcpy`

+ no system call

## Feedback

`strcpy()` doesn't invoke system calls, because it doesn't require any feature that is only provided by the operating system.
