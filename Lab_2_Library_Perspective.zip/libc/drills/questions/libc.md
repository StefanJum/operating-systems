# Syscall Tool

## Question Text

Which of following is **not** and advantage of using libc for programs?

## Question Answers

- increased portability

+ reduced executable size

- richer set of features

- easier development

## Feedback

When using libc, because we add a new software component, the size of the resulting executable increases.
