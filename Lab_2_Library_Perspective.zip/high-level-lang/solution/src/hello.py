#!/usr/bin/env python3

# SPDX-License-Identifier: BSD-3-Clause

print("Hello, world!")
